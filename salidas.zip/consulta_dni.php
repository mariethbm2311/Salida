<?php
//faltó el header
header('Content-Type: application/json');

//faltó verificación de DNI
if(!isset($_POST['dni'])) {
    echo json_encode(['error' => 'DNI no recibido']);
    exit;
}

//datos
$token = 'sk_10137.jfPSymYgiGcTDq2eT9u5FUrKoy30NbAB';
$dni = trim($_POST['dni']);

//llamada a api
$ch = curl_init();

//buscar dni - faltó arreglo dell array
curl_setopt_array($ch, array(
    CURLOPT_URL => "https://api.apis.net.pe/v1/dni?numero=" . $dni,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "Authorization: Bearer $token"
    ]
));

$response = curl_exec($ch);

//verifica errors
if(curl_errno($ch)){
    echo 'Error:' . curl_error($ch);
    exit;
}

curl_close($ch);

//datos a usar - faltó el true
$data = json_decode($response, true);

// Faltó: ⚠️ Validar si la API devolvió datos
if (isset($data['numeroDocumento'])) {
    echo json_encode([
        "dni" => $data['numeroDocumento'],
        "nombres" => $data['nombres'],
        "apellidoPaterno" => $data['apellidoPaterno'],
        "apellidoMaterno" => $data['apellidoMaterno']
    ]);
} else {
    echo json_encode(["error" => "DNI no encontrado en la API"]);
}
?>